import boto3  
import os
import datetime, time

# Environment variables
GROUP_NAME = os.environ['GROUP_NAME']
S3_DESTINATION_BUCKET = os.environ['S3_DESTINATION_BUCKET']
PREFIX = os.environ['PREFIX']
NUM_DAYS = os.environ['NUM_DAYS']
nDays = int(NUM_DAYS)

# Calculate StartDate and EndDate
currentTime = datetime.datetime.now()
StartDate = currentTime - datetime.timedelta(days=nDays)
EndDate = currentTime - datetime.timedelta(days=nDays - 1)

# Convert the Date to milliseconds
fromDate = int(StartDate.timestamp() * 1000)
toDate = int(EndDate.timestamp() * 1000)
 
# Create S3 bucket sub-folder structure based on year, month, day
BUCKET_PREFIX = os.path.join(PREFIX, StartDate.strftime('%Y{0}%m{0}%d').format(os.path.sep))
    

def lambda_handler(event, context):
    client = boto3.client('logs')
    max_retries = 10
    while max_retries > 0:
        try:
            response = client.create_export_task(
                         logGroupName=GROUP_NAME,
                         fromTime=fromDate,
                         to=toDate,
                         destination=S3_DESTINATION_BUCKET,
                         destinationPrefix=BUCKET_PREFIX
                        )
            print("    Task created: %s" % response['taskId'])
            break

        except client.exceptions.LimitExceededException:
            max_retries = max_retries - 1
            print("Need to wait until all tasks are finished (LimitExceededException). "
                  "Continuing %s additional times" % (max_retries))
            time.sleep(5)
            continue

        except Exception as e:
            print("Error exporting %s: %s" % (GROUP_NAME, getattr(e, 'message', repr(e))))
            break
